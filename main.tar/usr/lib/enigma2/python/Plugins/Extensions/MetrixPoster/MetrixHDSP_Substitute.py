#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import os
import sys
from datetime import datetime
from enigma import eEPGCache, getDesktop
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.MessageBox import MessageBox
from Screens.LocationBox import LocationBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection, getConfigListEntry, configfile
from Components.ConfigList import ConfigListScreen

# Import version from main plugin safely
try:
    from .plugin import PLUGIN_VERSION
except ImportError:
    PLUGIN_VERSION = "1.0"

# Handle Python 2/3 urllib differences
PY3 = sys.version_info[0] >= 3
if PY3:
    from urllib.request import urlopen, Request
    from urllib.parse import quote
else:
    from urllib2 import urlopen, Request
    from urllib import quote

# XML parser (cElementTree is faster but deprecated in Py3.3+; fallback to ElementTree)
try:
    from xml.etree.cElementTree import parse as ET_parse
    import xml.etree.cElementTree as ET
except ImportError:
    from xml.etree.ElementTree import parse as ET_parse
    import xml.etree.ElementTree as ET

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixPoster"

# =========================================================
# Screen resolution detection (used for skin selection)
# =========================================================
try:
    ScreenWidth = getDesktop(0).size().width()
except Exception:
    ScreenWidth = 720

if ScreenWidth >= 2560:
    ScreenWidth = '1440'
elif ScreenWidth >= 1920:
    ScreenWidth = '1080'
else:
    ScreenWidth = '720'

# =========================================================
# Skin XML loading
# =========================================================
try:
    skin_file = os.path.join(PLUGIN_PATH, 'skin', '%s.xml' % ScreenWidth)
    plugin_skin = ET_parse(skin_file).getroot()
except Exception as _e:
    print("[MetrixPoster] Substitute Error loading skin: %s" % str(_e))
    plugin_skin = None


def getSkin(skinName):
    if plugin_skin is not None:
        try:
            skin_element = plugin_skin.find('.//screen[@name="%s"]' % skinName)
            if skin_element is not None:
                if PY3:
                    return ET.tostring(skin_element, encoding='unicode', method='xml')
                else:
                    data = ET.tostring(
                        skin_element, encoding='utf-8', method='xml')
                    if isinstance(data, bytes) and data.startswith(b"<?xml"):
                        data = data[data.find(b'>') + 1:].lstrip()
                    return data
        except Exception as _e:
            print("[MetrixPoster] Error getting skin %s: %s" %
                  (skinName, str(_e)))
    return ''


# Initialize Global Configuration for the backup folder, search method, and title preference
if not hasattr(config.misc, "MetrixHDSubstitute"):
    config.misc.MetrixHDSubstitute = ConfigSubsection()
    config.misc.MetrixHDSubstitute.backup_dir = ConfigText(
        default="/etc/enigma2/metrixhd", fixed_size=False)
    config.misc.MetrixHDSubstitute.search_method = ConfigSelection(default="web", choices=[
        ("web", "Default Search (No API)"),
        ("api", "API Key Search")
    ])
    config.misc.MetrixHDSubstitute.name_preference = ConfigSelection(default="original_name", choices=[
        ("name", "Standard Name (Translated)"),
        ("original_name", "Original Name (Native)")
    ])


def write_sub_log(msg):
    """Writes log messages specifically for the substitution tool."""
    log_dir = "/var/volatile/tmp/agplog"
    log_file = os.path.join(log_dir, "metrix_substitute.log")
    try:
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        with open(log_file, "a") as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write("[{}] {}\n".format(timestamp, msg))
    except Exception:
        pass


class MetrixSubSettingsScreen(ConfigListScreen, Screen):
    fallback_skin = """
        <screen name="MetrixSubSettingsScreen" position="360,220" size="1200,800" title="Substitution Settings" flags="wfBorder" backgroundColor="#452606">
  <widget name="config" position="30,30" size="1140,675" itemHeight="45" font="Regular;30" itemCornerRadius="8" itemCornerRadiusSelected="8" itemGradientSelected="#e69138,#f9cb9c,#e69138,vertical" scrollbarMode="showOnDemand" scrollbarForegroundColor="#f9cb9c" scrollbarBorderColor="e69138" scrollbarWidth="10" scrollbarBorderWidth="1" scrollbarRadius="5" />
  <widget name="key_red" position="30,710" size="200,60" backgroundColor="#452606" font="Regular;26" halign="center" valign="center" />
  <widget name="key_green" position="250,710" size="200,60" backgroundColor="#452606" font="Regular;26" halign="center" valign="center" />
  <eLabel name="" position="30,770" size="200,10" backgroundColor="red" cornerRadius="5" />
  <eLabel name="" position="250,770" size="200,10" backgroundColor="green" cornerRadius="5" />
</screen>
    """

    def __init__(self, session):
        loaded_skin = getSkin("MetrixSubSettingsScreen")
        if loaded_skin:
            self.skin = loaded_skin
        else:
            self.skin = self.fallback_skin

        Screen.__init__(self, session)

        # Dynamically set title with version
        self.setTitle(
            "Substitution Settings - MetrixPoster v" + PLUGIN_VERSION)

        self.session = session

        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")

        self.folder_config = config.misc.MetrixHDSubstitute.backup_dir
        self.search_config = config.misc.MetrixHDSubstitute.search_method
        self.name_pref_config = config.misc.MetrixHDSubstitute.name_preference

        self.list = [
            getConfigListEntry("Search Method", self.search_config),
            getConfigListEntry("Title Preference", self.name_pref_config),
            getConfigListEntry(
                "Backup Folder (Press OK to change)", self.folder_config)
        ]

        ConfigListScreen.__init__(self, self.list, session=self.session)

        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "red": self.cancel,
            "green": self.save,
            "cancel": self.cancel,
            "ok": self.keyOK,
        }, -2)

    def keyOK(self):
        current = self["config"].getCurrent()
        if current and current[1] == self.folder_config:
            self.session.openWithCallback(
                self.locationCallback,
                LocationBox,
                windowTitle="Select Backup Folder",
                text="Select Folder",
                currDir=self.folder_config.value
            )

    def locationCallback(self, path):
        if path is not None:
            self.folder_config.value = path
            self["config"].invalidateCurrent()

    def save(self):
        self.search_config.save()
        self.name_pref_config.save()
        self.folder_config.save()
        configfile.save()
        self.close(True)

    def cancel(self):
        self.search_config.cancel()
        self.name_pref_config.cancel()
        self.folder_config.cancel()
        self.close(False)


class MetrixTitleSubstituteScreen(Screen):
    fallback_skin = """
        <screen name="MetrixTitleSubstituteScreen" position="360,220" size="1200,800" title="EPG Title Substitution" flags="wfBorder" backgroundColor="#452606">
  <eLabel name="" position="30,780" size="200,10" backgroundColor="red" cornerRadius="5" />
  <eLabel name="" position="250,780" size="200,10" backgroundColor="green" cornerRadius="5" />
  <eLabel name="" position="470,780" size="200,10" backgroundColor="yellow" cornerRadius="5" />
  <widget name="key_red" position="30,720" size="200,60" backgroundColor="#452606" font="Regular;26" halign="center" valign="center" />
  <widget name="key_green" position="250,720" size="200,60" backgroundColor="#452606" font="Regular;26" halign="center" valign="center" />
  <widget name="key_yellow" position="470,720" size="200,60" backgroundColor="#452606" font="Regular;26" halign="center" valign="center" />
  <widget name="key_menu" position="990,720" size="180,60" zPosition="1" font="Regular;26" halign="center" valign="center" foregroundColor="#00aaff" transparent="1" />
  <widget name="original_label" position="30,20" size="320,40" font="Regular;26" halign="left" valign="center" />
  <widget name="original_name" position="370,20" size="800,40" font="Regular;26" halign="left" valign="center" foregroundColor="#cccccc" />
  <widget name="editable_label" position="30,70" size="320,40" font="Regular;26" halign="left" valign="center" />
  <widget name="editable_name" position="370,70" size="800,40" font="Regular;26" halign="left" valign="center" foregroundColor="#ffff00" />
  <widget name="results_list" position="30,130" size="1140,540" itemHeight="45" font="Regular;30" itemCornerRadius="8" itemCornerRadiusSelected="8" itemGradientSelected="#e69138,#f9cb9c,#e69138,vertical" scrollbarMode="showOnDemand" scrollbarForegroundColor="#f9cb9c" scrollbarBorderColor="e69138" scrollbarWidth="10" scrollbarBorderWidth="1" scrollbarRadius="5" />
</screen>
    """

    def __init__(self, session):
        loaded_skin = getSkin("MetrixTitleSubstituteScreen")
        if loaded_skin:
            self.skin = loaded_skin
        else:
            self.skin = self.fallback_skin

        Screen.__init__(self, session)

        # Dynamically set title with version
        self.setTitle(
            "EPG Title Substitution - MetrixPoster v" + PLUGIN_VERSION)

        self.session = session

        self["key_red"] = Label("Edit Event Name")
        self["key_green"] = Label("Search TMDb")
        self["key_yellow"] = Label("Save Selected")
        self["key_menu"] = Label("MENU: Settings")

        self["original_label"] = Label("Event Name (< / >):")
        self["editable_label"] = Label("Search Query:")

        self["original_name"] = Label("")
        self["editable_name"] = Label("")

        self.search_results = []
        self["results_list"] = MenuList([])

        # Load the event timeline and set the display
        self.loadEvents()
        self.updateEventDisplay()

        # Added 'left' and 'right' mapping to cycle through events
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "SetupActions"], {
            "cancel": self.handleExit,
            "red": self.openKeyboard,
            "green": self.searchTMDb,
            "yellow": self.saveSubstitution,
            "ok": self.saveSubstitution,
            "menu": self.openSettings,
            "up": self.goUp,
            "down": self.goDown,
            "left": self.prevEvent,
            "right": self.nextEvent
        }, -1)

        # Pull dynamic API key from main MetrixPoster configuration with hardcoded fallback
        user_key = ""
        if hasattr(config.plugins, "MetrixHDSP") and hasattr(config.plugins.MetrixHDSP, "tmdb_api"):
            user_key = config.plugins.MetrixHDSP.tmdb_api.value.strip()

        self.tmdb_api_key = user_key if user_key else "3c3efcf47c3577558812bb9d64019d65"

        self.pending_save = None

    def loadEvents(self):
        """Fetches up to 24 hours of events for the current service to allow navigation."""
        self.events_list = []
        self.current_event_index = 0

        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        if ref:
            epgcache = eEPGCache.getInstance()
            if epgcache is not None:
                # 'T' = Title only. 1 = Look forward in time, -1 = Start from now, 1440 = Next 24 hrs
                events = epgcache.lookupEvent(
                    ['T', (ref.toString(), 1, -1, 1440)])
                if events:
                    seen = set()
                    for evt in events:
                        if evt and evt[0]:
                            name = evt[0].strip()
                            if name and name not in seen:
                                self.events_list.append(name)
                                seen.add(name)

        # Fallback if cache fails or timeline is completely empty
        if not self.events_list:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            event = info and info.getEvent(0)
            if event:
                name = event.getEventName()
                self.events_list = [name.strip() if name else "No Event"]
            else:
                self.events_list = ["No Event"]

    def updateEventDisplay(self):
        """Updates the labels when navigating between events."""
        self.original_title = self.events_list[self.current_event_index]
        self.editable_title = self.original_title

        self["original_name"].setText(self.original_title)
        self["editable_name"].setText(self.editable_title)

        # Clear any old search results when switching events
        self.search_results = []
        self["results_list"].setList([])

    def nextEvent(self):
        if self.current_event_index < len(self.events_list) - 1:
            self.current_event_index += 1
            self.updateEventDisplay()

    def prevEvent(self):
        if self.current_event_index > 0:
            self.current_event_index -= 1
            self.updateEventDisplay()

    def openSettings(self):
        self.session.open(MetrixSubSettingsScreen)

    def openKeyboard(self):
        self.session.openWithCallback(
            self.keyboardCallback,
            VirtualKeyBoard,
            title="Edit Search Query",
            text=self.editable_title
        )

    def keyboardCallback(self, res):
        if res is not None:
            self.editable_title = res.strip()
            self["editable_name"].setText(self.editable_title)

    def goUp(self):
        self["results_list"].up()

    def goDown(self):
        self["results_list"].down()

    def searchTMDb(self):
        if not self.editable_title or self.editable_title == "No Event":
            return

        search_mode = config.misc.MetrixHDSubstitute.search_method.value
        name_pref = config.misc.MetrixHDSubstitute.name_preference.value

        if search_mode == "api":
            url = "https://api.themoviedb.org/3/search/multi?api_key={}&query={}".format(
                self.tmdb_api_key, quote(self.editable_title))
            write_sub_log("Initiating TMDb API Key search for query: '{}'".format(
                self.editable_title))
            headers = {'User-Agent': 'Mozilla/5.0'}
        else:
            url = "https://www.themoviedb.org/search/trending?query={}".format(
                quote(self.editable_title))
            write_sub_log("Initiating TMDb Web Search (No API) for query: '{}'".format(
                self.editable_title))
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'X-Requested-With': 'XMLHttpRequest'
            }

        try:
            req = Request(url, headers=headers)
            response = urlopen(req, timeout=5).read()
            data = json.loads(response.decode('utf-8'))

            self.search_results = []
            display_list = []

            results = data.get("results", [])
            write_sub_log(
                "Search returned {} total items.".format(len(results)))

            for item in results:
                if not isinstance(item, dict):
                    continue

                media_type = item.get("media_type", "")
                if media_type in ("movie", "tv"):
                    if name_pref == "original_name":
                        title = item.get("original_title") or item.get(
                            "original_name") or item.get("title") or item.get("name")
                    else:
                        title = item.get("title") or item.get("name")

                    year = item.get("release_date", "")[
                        :4] or item.get("first_air_date", "")[:4]

                    if title:
                        display_text = "{} ({})".format(
                            title, year) if year else title
                        display_list.append(display_text)
                        self.search_results.append((title, year))

                        write_sub_log("Result Discovered | Title: '{}' | Year: '{}' | Type: '{}'".format(
                            title, year, media_type))

            if display_list:
                self["results_list"].setList(display_list)
            else:
                self["results_list"].setList(["No results found"])
                self.search_results = []
                write_sub_log("No matching movie or TV results found for query: '{}'".format(
                    self.editable_title))

        except Exception as e:
            write_sub_log("Search Error: {}".format(str(e)))
            self["results_list"].setList(["Search Error: " + str(e)])

    def saveSubstitution(self):
        if not self.search_results:
            return

        selected_index = self["results_list"].getSelectedIndex()
        if selected_index < 0 or selected_index >= len(self.search_results):
            return

        tmdb_title, tmdb_year = self.search_results[selected_index]

        original_clean = self.original_title.lower().strip()
        tmdb_clean = tmdb_title.lower().strip()
        editable_clean = self.editable_title.lower().strip()

        replacement_value = tmdb_clean
        method = "replace" if original_clean == editable_clean else "set"

        self.pending_save = (original_clean, replacement_value, method)

        backup_dir = config.misc.MetrixHDSubstitute.backup_dir.value
        json_path = os.path.join(backup_dir, "substitutions.json")
        duplicate_found = False

        if os.path.exists(json_path):
            try:
                import codecs
                with codecs.open(json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for item in data:
                        if item[0] == original_clean:
                            duplicate_found = True
                            break
            except Exception as e:
                write_sub_log("Duplicate check error: " + str(e))

        if duplicate_found:
            self.session.openWithCallback(
                self.overrideCallback,
                MessageBox,
                "This event name already exists in substitutions.json.\nDo you want to override it?",
                MessageBox.TYPE_YESNO
            )
        else:
            self.writeToJson(override=False)

    def overrideCallback(self, answer):
        if answer:
            self.writeToJson(override=True)
        else:
            write_sub_log("Save cancelled by user (duplicate entry rejected).")

    def writeToJson(self, override):
        orig, replacement, method = self.pending_save
        backup_dir = config.misc.MetrixHDSubstitute.backup_dir.value

        if not os.path.exists(backup_dir):
            try:
                os.makedirs(backup_dir)
            except Exception as e:
                self.session.open(
                    MessageBox,
                    "Directory creation error: " + str(e),
                    MessageBox.TYPE_ERROR
                )
                return

        json_path = os.path.join(backup_dir, "substitutions.json")
        data = []

        import codecs
        if os.path.exists(json_path):
            try:
                with codecs.open(json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                pass

        if override:
            for item in data:
                if item[0] == orig:
                    item[1] = replacement
                    item[2] = method
                    break
            write_sub_log(
                "Overrode entry in JSON -> Original: '{}' | Target: '{}' | Method: '{}'".format(orig, replacement, method))
        else:
            data.append([orig, replacement, method])
            write_sub_log(
                "Saved entry to JSON -> Original: '{}' | Target: '{}' | Method: '{}'".format(orig, replacement, method))

        try:
            with codecs.open(json_path, "w", encoding="utf-8") as f:
                import sys
                if sys.version_info[0] >= 3:
                    json.dump(data, f, indent=4, ensure_ascii=False)
                else:
                    json.dump(data, f, indent=4)

            self.session.open(
                MessageBox,
                "Substitution saved to JSON successfully!\nYou can continue adding more.",
                MessageBox.TYPE_INFO
            )
        except Exception as e:
            self.session.open(
                MessageBox,
                "JSON Write Error: " + str(e),
                MessageBox.TYPE_ERROR
            )

    def handleExit(self):
        self.close()
