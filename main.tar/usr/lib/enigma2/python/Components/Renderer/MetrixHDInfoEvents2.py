#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
from Components.config import config, ConfigSubsection, ConfigOnOff, ConfigYesNo, ConfigText
from .MetrixHD_lib import build_search_title, quoteEventName, clean_search_title, smart_capitalize_title, should_skip_title
from .MetrixHD_Utils import IMOVIE_FOLDER, logger
from ServiceReference import ServiceReference
import NavigationInstance
from Components.Sources.ServiceEvent import ServiceEvent
from Components.Sources.CurrentService import CurrentService
from Components.Sources.EventInfo import EventInfo
from Components.Sources.Event import Event
from Components.VariableText import VariableText
from Components.Renderer.Renderer import Renderer
from enigma import eLabel, eEPGCache, eTimer

import sys
from json import load as json_load, dump as json_dump
from threading import Lock, Thread
from os.path import exists, join, getsize
from re import findall
import gettext

# Python 2/3 compatibility for urlopen
PY3 = sys.version_info[0] >= 3
if PY3:
    from urllib.request import urlopen
else:
    from urllib2 import urlopen

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass


# ==========================================
# PLUGIN CONFIGURATION FOR THIS RENDERER
# ==========================================

if not hasattr(config.plugins, "MetrixHDSP"):
    config.plugins.MetrixHDSP = ConfigSubsection()

if not hasattr(config.plugins.MetrixHDSP, "info_display_mode"):
    config.plugins.MetrixHDSP.info_display_mode = ConfigOnOff(default=True)
if not hasattr(config.plugins.MetrixHDSP, "genre_source"):
    config.plugins.MetrixHDSP.genre_source = ConfigOnOff(default=True)
if not hasattr(config.plugins.MetrixHDSP, "rating_source"):
    config.plugins.MetrixHDSP.rating_source = ConfigOnOff(default=True)
if not hasattr(config.plugins.MetrixHDSP, "tmdb_api"):
    config.plugins.MetrixHDSP.tmdb_api = ConfigText(
        default="3c3efcf47c3577558812bb9d64019d65", visible_width=50, fixed_size=False)
if not hasattr(config.plugins.MetrixHDSP, "load_tmdb_api"):
    config.plugins.MetrixHDSP.load_tmdb_api = ConfigYesNo(default=False)

cfg = config.plugins.MetrixHDSP


class ApiKeyManager:
    def __init__(self):
        self.plugin_api_file = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixPoster/tmdb_api"

    def get_tmdb_key(self):
        if cfg.load_tmdb_api.value and exists(self.plugin_api_file):
            try:
                with open(self.plugin_api_file, "r") as f:
                    key = f.read().strip()
                    if key:
                        return key
            except Exception:
                pass
        return cfg.tmdb_api.value


api_key_manager = ApiKeyManager()
# ==========================================

if not IMOVIE_FOLDER.endswith("/"):
    IMOVIE_FOLDER += "/"

epgcache = eEPGCache.getInstance()
api_lock = Lock()
_ = gettext.gettext

try:
    lng = config.osd.language.value
    lng = lng[:-3]
except BaseException:
    lng = 'en'


class MetrixHDInfoEvents2(Renderer, VariableText):
    GUI_WIDGET = eLabel

    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)

        self.current_request = None
        self.current_request_key = None
        self.pending_display_key = None
        self.pending_display_text = ""
        self.last_event = None
        self.last_prefetch_key = None
        self.lock = Lock()
        self.text = ""
        self.nxts = 0
        self.canal = [None] * 6
        self.oldCanal = None

        self.adsl = True
        self._last_event_list_log = None
        self.storage_path = IMOVIE_FOLDER
        self.timer = eTimer()
        self.timer.callback.append(self.delayed_update)
        logger.info("MetrixHDInfoEvents2 Renderer initialized")

    def applySkin(self, desktop, screen):
        attribs = []
        for attrib, value in self.skinAttributes:
            if attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            elif attrib == 'path':
                self.storage_path = str(value)
            else:
                attribs.append((attrib, value))
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, screen)

    def detect_expected_media_type(self):
        try:
            desc = "{}\n{}\n{}".format(
                self.canal[2] if self.canal and len(self.canal) > 2 else "",
                self.canal[4] if self.canal and len(self.canal) > 4 else "",
                self.canal[3] if self.canal and len(self.canal) > 3 else ""
            ).lower()

            tv_markers = [
                "odc.", "odc ", "odcinek", "episode", "ep.", "ep ",
                "serial", "serie", "series", "season", "saison"
            ]
            movie_markers = [
                "film", "movie", "cinema", "feature film"
            ]

            if any(marker in desc for marker in tv_markers):
                return "tv"
            if any(marker in desc for marker in movie_markers):
                return "movie"
            return None
        except Exception:
            return None

    def get_search_title(self, title, shortdesc="", fulldesc=""):
        try:
            result = build_search_title(
                title or "", shortdesc or "", fulldesc or "")
            return smart_capitalize_title(result)
        except Exception:
            return smart_capitalize_title(clean_search_title(title or ""))

    def _clear_display(self):
        self.text = ""
        self.pending_display_key = None
        self.pending_display_text = ""
        try:
            if self.timer.isActive():
                self.timer.stop()
        except Exception:
            pass
        if self.instance:
            self.instance.hide()

    def _strip_service_name(self, service):
        try:
            return ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
        except Exception:
            return ""

    def _resolve_event_from_source(self):
        source = self.source
        source_type = type(source)
        service = None

        if self.nxts == 0 and getattr(source, "event", None) is not None:
            event = source.event
            self.canal = [None] * 6
            self.canal[1] = event.getBeginTime()
            self.canal[2] = event.getEventName()
            self.canal[3] = event.getExtendedDescription()
            self.canal[4] = event.getShortDescription()
            self.canal[5] = event.getEventName()
            return True

        if source_type is ServiceEvent:
            service = source.getCurrentService()
        elif source_type is CurrentService:
            service = source.getCurrentServiceRef()
        elif source_type is EventInfo or source_type is Event:

            service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()

        if service is None:
            return False

        service_str = service.toString()

        if self.nxts == 1:
            events = epgcache.lookupEvent(
                ['IBDCTESX', (service_str, 1, -1, -1)])
            idx = 0
        elif self.nxts > 1:
            events = epgcache.lookupEvent(
                ['IBDCTESX', (service_str, -1, -1, 1440)])
            idx = self.nxts
        else:
            events = epgcache.lookupEvent(
                ['IBDCTESX', (service_str, 0, -1, -1)])
            idx = 0

        if not events or len(events) <= idx:
            return False

        evt = events[idx]
        self.canal = [None] * 6
        self.canal[0] = self._strip_service_name(service)
        self.canal[1] = evt[1]
        self.canal[2] = evt[4]
        self.canal[3] = evt[5]
        self.canal[4] = evt[6]
        self.canal[5] = self.canal[2]
        return True

    def changed(self, what):
        try:
            is_enabled = config.plugins.MetrixHDSP.info_display_mode.value
        except Exception:
            is_enabled = True

        if what is None or not self.adsl or not is_enabled:
            self._clear_display()
            return

        if what[0] == self.CHANGED_CLEAR:
            self._last_event_list_log = None
            self.oldCanal = None
            self.current_request_key = None
            self._clear_display()
            return

        try:
            if not self._resolve_event_from_source() or not self.canal[5]:
                self.oldCanal = None
                self.current_request_key = None
                self._clear_display()
                return

            curCanal = "%s-%s-%s" % (self.nxts, self.canal[1], self.canal[2])
            if curCanal == self.oldCanal:
                return

            self.oldCanal = curCanal
            self._clear_display()
            self.start_data_fetch()

        except Exception as e:
            logger.error("MetrixHDInfoEvents2 changed error: {}".format(
                str(e)), exc_info=True)
            self.oldCanal = None
            self.current_request_key = None
            self._clear_display()

    def start_data_fetch(self):
        request_key = "%s-%s-%s" % (
            self.nxts,
            self.canal[1] if self.canal and len(self.canal) > 1 else "",
            self.canal[2] if self.canal and len(self.canal) > 2 else ""
        )

        if getattr(self, "current_request_key", None) == request_key:
            if self.current_request and self.current_request.is_alive():
                return

        self.current_request_key = request_key
        self.current_request = Thread(
            target=self.fetch_event_data, args=(request_key,))
        self.current_request.daemon = True
        self.current_request.start()

    def extract_year_from_canal(self):
        try:
            desc = "{}\n{}\n{}".format(
                self.canal[2] if self.canal and len(self.canal) > 2 else "",
                self.canal[4] if self.canal and len(self.canal) > 4 else "",
                self.canal[3] if self.canal and len(self.canal) > 3 else ""
            )
            years = findall(r'\b\d{4}\b', desc)
            if years:
                valid_years = [y for y in years if 1900 <= int(y) <= 2100]
                if valid_years:
                    return max(valid_years)
            return None
        except Exception:
            return None

    def fetch_event_data(self, request_key=None):
        try:
            is_enabled = config.plugins.MetrixHDSP.info_display_mode.value
        except Exception:
            is_enabled = True

        if not is_enabled:
            return

        with self.lock:
            try:
                if request_key is not None and request_key != self.current_request_key:
                    return

                clean_title = self.get_search_title(
                    self.canal[5], self.canal[4], self.canal[3])
                skip_title, skip_word = should_skip_title(clean_title)
                if skip_title:
                    self.current_request_key = None
                    self._clear_display()
                    return

                json_file = join(self.storage_path,
                                 "{}.json".format(clean_title))
                year = self.extract_year_from_canal()
                data = None

                if exists(json_file) and getsize(json_file) > 0:
                    with open(json_file, "r") as f:
                        data = json_load(f)

                else:
                    data = self.fetch_tmdb_data(clean_title, year)

                    if data:
                        with open(json_file, "w") as f:
                            json_dump(data, f, indent=2)

                if request_key is not None and request_key != self.current_request_key:
                    return

                if data:
                    self.process_data(data, request_key=request_key)
                else:
                    self.current_request_key = None
                    self._clear_display()

                if self.nxts == 0:
                    self.prefetch_next_event_json()

            except Exception as e:
                logger.error("MetrixHDInfoEvents2 Data fetch error: {}".format(
                    str(e)), exc_info=True)
                self.current_request_key = None
                self._clear_display()

    def prefetch_next_event_json(self):
        try:
            service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
            if service is None:
                return

            service_str = service.toString()
            events = epgcache.lookupEvent(
                ['IBDCTESX', (service_str, 1, -1, -1)])
            if not events:
                return

            evt = events[0]
            next_title_raw = evt[4]
            if not next_title_raw:
                return

            clean_title = self.get_search_title(next_title_raw, evt[6], evt[5])
            skip_title, skip_word = should_skip_title(clean_title)
            if skip_title:
                return

            json_file = join(self.storage_path, "{}.json".format(clean_title))
            if exists(json_file) and getsize(json_file) > 0:
                return

            desc = "{}\n{}\n{}".format(evt[4], evt[6], evt[5])
            years = findall(r'\b\d{4}\b', desc)
            year = None
            if years:
                valid_years = [y for y in years if 1900 <= int(y) <= 2100]
                if valid_years:
                    year = max(valid_years)

            prefetch_key = "{}::{}".format(
                self.canal[2] if self.canal and len(self.canal) > 2 else "", clean_title)
            if prefetch_key == self.last_prefetch_key:
                return
            self.last_prefetch_key = prefetch_key

            data = self.fetch_tmdb_data(clean_title, year)

            if data:
                with open(json_file, "w") as f:
                    json_dump(data, f, indent=2)

        except Exception:
            pass

    def fetch_tmdb_data(self, title, year):
        try:
            api_key = api_key_manager.get_tmdb_key()
            expected_type = self.detect_expected_media_type()
            search_year = year if expected_type == "movie" else None

            search_url = (
                "https://api.themoviedb.org/3/search/multi?api_key=" + api_key +
                "&language=" + lng +
                "&query=" + quoteEventName(title) +
                ("&year=" + str(search_year) if search_year else "")
            )

            with urlopen(search_url) as response:
                search_data = json_load(response)

            if not search_data.get("results"):
                return None

            result = self.select_best_result(search_data["results"], title)
            content_type = result["media_type"]
            content_id = result["id"]

            append_parts = ["credits"]
            if content_type == "movie":
                append_parts.append("release_dates")
            elif content_type == "tv":
                append_parts.append("content_ratings")

            details_url = (
                "https://api.themoviedb.org/3/" +
                content_type +
                "/" +
                str(content_id) +
                "?api_key=" +
                api_key +
                "&language=" +
                lng +
                "&append_to_response=" + ",".join(append_parts)
            )

            with urlopen(details_url) as response:
                return json_load(response)

        except Exception:
            return None

    def select_best_result(self, results, original_title):
        target = str(original_title or "").strip().lower()
        expected_type = self.detect_expected_media_type()

        desc = "{}\n{}\n{}".format(
            self.canal[2] if self.canal and len(self.canal) > 2 else "",
            self.canal[4] if self.canal and len(self.canal) > 4 else "",
            self.canal[3] if self.canal and len(self.canal) > 3 else ""
        )
        years = findall(r'\b\d{4}\b', desc)
        year = None
        if years:
            valid_years = [y for y in years if 1900 <= int(y) <= 2100]
            if valid_years:
                year = max(valid_years)

        scored = []
        for result in results:
            media_type = result.get('media_type')
            if media_type not in ('movie', 'tv'):
                continue

            name = (result.get('title') or result.get(
                'name') or "").strip().lower()
            original_name = (result.get('original_title') or result.get(
                'original_name') or "").strip().lower()
            result_year = (result.get('release_date')
                           or result.get('first_air_date') or "")[:4]

            score = 0

            if name == target:
                score += 500
            if original_name == target:
                score += 500
            if target and target in name:
                score += 120
            if target and target in original_name:
                score += 120

            if expected_type == "tv":
                if media_type == "tv":
                    score += 350
                else:
                    score -= 350
            elif expected_type == "movie":
                if media_type == "movie":
                    score += 350
                else:
                    score -= 350

            if year and media_type == "movie":
                if result_year:
                    if str(result_year) == str(year):
                        score += 600
                    else:
                        score -= 500
                else:
                    score -= 150

            try:
                score += min(float(result.get('popularity', 0)), 10)
            except Exception:
                pass

            scored.append((result, score, result_year))

        if not scored:
            return results[0]

        if year:
            exact_year = [(r, s)
                          for r, s, ry in scored if str(ry) == str(year)]
            if exact_year:
                exact_year.sort(key=lambda x: x[1], reverse=True)
                return exact_year[0][0]

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[0][0]

    def _extract_title(self, data):
        return (data.get('title') or data.get('name') or "").strip()

    def _extract_year(self, data):
        value = data.get('release_date') or data.get(
            'first_air_date') or ""
        if value:
            return str(value).split('-')[0].strip()
        return ""

    def _extract_runtime_text(self, data):
        runtime = data.get('runtime') or ""
        if isinstance(runtime, int):
            minutes = runtime
        else:
            digits = "".join(ch for ch in str(runtime) if ch.isdigit())
            minutes = int(digits) if digits else 0

        if minutes <= 0:
            return ""

        hours = minutes // 60
        mins = minutes % 60
        if hours > 0:
            return "{} h {} min".format(hours, mins)
        return "{} min".format(mins)

    def _extract_genres_text(self, data):
        names = []
        if data.get('genres'):
            for item in data.get('genres', []):
                name = (item.get('name') or "").strip()
                if name:
                    names.append(name)

        names = names[:3]
        return " • ".join(names)

    def _extract_rating_text(self, data):
        tmdb_rating = data.get('vote_average')
        star_text = ""
        imdb_text = ""

        try:
            if tmdb_rating not in (None, "", 0, "0"):
                tmdb_float = float(tmdb_rating)
                star_text = "★ {}/5".format(round(tmdb_float / 2.0, 1))
                imdb_text = "IMDb {}/10".format(round(tmdb_float, 1))
        except Exception:
            pass

        parts = []
        if star_text:
            parts.append(star_text)
        if imdb_text:
            parts.append(imdb_text)
        return "   ".join(parts)

    def _extract_overview(self, data):
        return (data.get('overview') or "").strip()

    def process_data(self, data, request_key=None):
        try:
            if request_key is not None and request_key != self.current_request_key:
                return

            try:
                show_genres = config.plugins.MetrixHDSP.genre_source.value
                show_rating = config.plugins.MetrixHDSP.rating_source.value
            except Exception:
                show_genres = True
                show_rating = True

            title = self._extract_title(data)
            year = self._extract_year(data)
            runtime = self._extract_runtime_text(data)
            genres = self._extract_genres_text(data)
            rating_row = self._extract_rating_text(data)
            overview = self._extract_overview(data)

            lines = []

            title_line = title
            if year and ("({})".format(year) not in title_line):
                title_line = "{} ({})".format(title_line, year)
            if title_line:
                lines.append(title_line)

            if show_genres and genres:
                lines.append(genres)

            meta_parts = []
            if show_rating and rating_row:
                meta_parts.append(rating_row)
            if year:
                meta_parts.append(year)
            if runtime:
                meta_parts.append(runtime)

            if meta_parts:
                lines.append("   ".join(meta_parts))

            if overview:
                lines.append("")
                lines.append(overview)

            new_text = "\n".join(lines).strip()
            if not new_text:
                self.current_request_key = None
                self._clear_display()
                return

            if new_text == self.text:
                self.current_request_key = None
                return

            self.pending_display_key = request_key
            self.pending_display_text = new_text

            self.current_request_key = None
            self.timer.start(100, True)

        except Exception as e:
            logger.error(
                "MetrixHDInfoEvents2 Data processing error: {}".format(str(e)), exc_info=True)
            self.current_request_key = None
            self._clear_display()

    def delayed_update(self):
        if not self.instance:
            return

        if not self.pending_display_text:
            self.text = ""
            self.instance.hide()
            return

        self.text = self.pending_display_text
        self.instance.setText(self.text)

        if self.text:
            self.instance.show()
        else:
            self.instance.hide()

    def extract_year(self, event):
        try:
            desc = "{}\n{}\n{}".format(
                event.getEventName(),
                event.getShortDescription(),
                event.getExtendedDescription()
            )
            years = findall(r'\b\d{4}\b', desc)
            if years:
                valid_years = [y for y in years if 1900 <= int(y) <= 2100]
                if valid_years:
                    return max(valid_years)
            return None
        except Exception:
            return None

    def onHide(self):
        try:
            if self.timer.isActive():
                self.timer.stop()
        except Exception:
            pass

    def onShow(self):
        pass
