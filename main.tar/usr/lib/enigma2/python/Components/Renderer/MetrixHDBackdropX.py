#!/usr/bin/python
# -*- coding: utf-8 -*-
###################################
# #__author__ = "Lululla"       # #
# #__copyright__ = "AGP Team"   # #
# #__modified_by__ = "MNASR"    # #
###################################
from __future__ import absolute_import, print_function
from Components.config import config, ConfigSubsection, ConfigOnOff, ConfigYesNo, ConfigText
from .MetrixHD_lib import build_search_title, clean_search_title, smart_capitalize_title, should_skip_title
from .MetrixHD_Utils import (
    BACKDROP_FOLDER,
    check_disk_space,
    delete_old_files_if_low_disk_space,
    validate_media_path,
    clean_for_tvdb,
    logger,
    create_secure_log_dir
)
from Components.Renderer.MetrixHDbDownloadThread import MetrixHDbDownloadThread

# Standard library
from datetime import datetime
from os import remove, makedirs
from os.path import join, exists, getsize
from re import compile, sub
import threading
from threading import Thread, Lock
from datetime import timedelta
from time import sleep, time
from traceback import print_exc, format_exc
from collections import OrderedDict
from queue import Queue
from concurrent.futures import ThreadPoolExecutor

# Enigma2 specific imports
from enigma import ePixmap, loadJPG, eEPGCache, eTimer
from Components.Renderer.Renderer import Renderer
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
from ServiceReference import ServiceReference
import NavigationInstance


# Ensure the config exists in the renderer namespace in case plugin hasn't initialized it yet
if not hasattr(config.plugins, "MetrixHDSP"):
    config.plugins.MetrixHDSP = ConfigSubsection()

if not hasattr(config.plugins.MetrixHDSP, "show_backdrop"):
    config.plugins.MetrixHDSP.show_backdrop = ConfigOnOff(default=True)
if not hasattr(config.plugins.MetrixHDSP, "tmdb_api"):
    config.plugins.MetrixHDSP.tmdb_api = ConfigText(
        default="3c3efcf47c3577558812bb9d64019d65", visible_width=50, fixed_size=False)
if not hasattr(config.plugins.MetrixHDSP, "load_tmdb_api"):
    config.plugins.MetrixHDSP.load_tmdb_api = ConfigYesNo(default=False)

cfg = config.plugins.MetrixHDSP


class ApiKeyManager:
    def __init__(self):
        self.plugin_api_file = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixPoster/tmdb_api"

    def get_tmdb_key(self):
        # If user selected to load from file, try reading it
        if cfg.load_tmdb_api.value and exists(self.plugin_api_file):
            try:
                with open(self.plugin_api_file, "r") as f:
                    key = f.read().strip()
                    if key:
                        return key
            except Exception:
                pass
        # Fallback to the text setting (which defaults to the hardcoded key)
        return cfg.tmdb_api.value


api_key_manager = ApiKeyManager()


secure_log_dir = create_secure_log_dir()

if not BACKDROP_FOLDER.endswith("/"):
    BACKDROP_FOLDER += "/"

# Constants and global variables
epgcache = eEPGCache.getInstance()
epgcache.load()
pdb = Queue()

extensions = ['.jpg']
autobouquet_file = None
abdb = dict()


def get_search_title(title, shortdesc="", fulldesc=""):
    try:
        result = build_search_title(
            title or "", shortdesc or "", fulldesc or "")
        return smart_capitalize_title(result)
    except Exception:
        return smart_capitalize_title(clean_search_title(title or ""))


global global_agb_auto_db
AgbDB = None
db_lock = Lock()
global_agb_auto_db = None


class MetrixHDBackdropX(Renderer):
    """
    Main Backdrop renderer class for Enigma2
    Handles Backdrop display and refresh logic
    """
    GUI_WIDGET = ePixmap

    def __init__(self):
        """Initialize the backdrop renderer"""
        Renderer.__init__(self)

        self._stop_event = threading.Event()
        self._active_event = threading.Event()
        self._active_event.set()
        self.backdrop_cache = {}
        self.queued_backdrops = set()
        self.storage_path = BACKDROP_FOLDER
        self.extensions = extensions
        self.nxts = 0

        self.canal = [None] * 6
        self.oldCanal = None
        self.pstcanal = None
        self.pstrNm = None
        self.backrNm = None
        self.backdrop_refresh_count = 0
        self.backdrop_refresh_max = 20
        self.backdrop_refresh_delay = 300
        self.log_file = join(secure_log_dir, "MetrixHDBackdropX.log")
        clear_all_log()

        self.adsl = True

        if len(self.backdrop_cache) > 50:
            self.backdrop_cache.clear()

        self.show_timer = eTimer()
        self.show_timer.callback.append(self.refreshBackdrop)

        self.backdrop_db = AgbDB
        self.backdrop_auto_db = global_agb_auto_db

    def applySkin(self, desktop, parent):
        attribs = []
        for attrib, value in self.skinAttributes:
            if attrib == "nexts":
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            elif attrib == "path":
                self.storage_path = str(value)
                try:
                    if not exists(self.storage_path):
                        makedirs(self.storage_path, exist_ok=True)
                except Exception as e:
                    logger.error("Failed to create backdrop path {}: {}".format(
                        self.storage_path, str(e)))
            else:
                attribs.append((attrib, value))

        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    def changed(self, what):
        """Handle screen/channel changes and update backdrop"""
        if not self.instance:
            return

        if what[0] not in (self.CHANGED_DEFAULT, self.CHANGED_ALL, self.CHANGED_SPECIFIC, self.CHANGED_CLEAR):
            if self.instance:
                self.instance.hide()
            return

        source = self.source
        source_type = type(source)
        servicetype = None
        service = None
        try:
            if source_type is ServiceEvent:
                service = source.getCurrentService()
                servicetype = "ServiceEvent"
            elif source_type is CurrentService:
                service = source.getCurrentServiceRef()
                servicetype = "CurrentService"
            elif source_type is EventInfo:
                service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                servicetype = "EventInfo"
            elif source_type is Event:
                servicetype = "Event"

                if self.nxts:
                    service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
                else:
                    if getattr(source, "event", None) is None:
                        self.oldCanal = None
                        if self.instance:
                            self.instance.hide()
                        return

                    event = source.event
                    bt = event.getBeginTime()
                    if bt is not None:
                        self.canal[1] = bt

                    event_name = sub(
                        r"[\u0000-\u001F\u007F-\u009F]", "", event.getEventName() or "")
                    if not event_name:
                        self.oldCanal = None
                        if self.instance:
                            self.instance.hide()
                        return

                    self.canal[2] = event_name
                    self.canal[3] = event.getExtendedDescription()
                    self.canal[4] = event.getShortDescription()
                    self.canal[5] = event_name
            else:
                servicetype = None

            if service is not None:
                service_str = service.toString()
                events = epgcache.lookupEvent(
                    ['IBDCTESX', (service_str, 0, -1, -1)])

                if not events or len(events) <= self.nxts:
                    self.oldCanal = None
                    if self.instance:
                        self.instance.hide()
                    return

                service_name = ServiceReference(service).getServiceName().replace(
                    '\xc2\x86', '').replace('\xc2\x87', '')
                self.canal = [None] * 6
                self.canal[0] = service_name
                self.canal[1] = events[self.nxts][1]
                self.canal[2] = events[self.nxts][4]
                self.canal[3] = events[self.nxts][5]
                self.canal[4] = events[self.nxts][6]
                self.canal[5] = self.canal[2]

                if not autobouquet_file and service_name not in abdb:
                    abdb[service_name] = service_str

            if not servicetype or not self.canal[5]:
                self.oldCanal = None
                if self.instance:
                    self.instance.hide()
                return

            curCanal = f"{self.canal[1]}-{self.canal[2]}"
            if curCanal == self.oldCanal:
                return

            if self.instance:
                self.instance.hide()

            self.oldCanal = curCanal
            self.pstcanal = get_search_title(
                self.canal[5], self.canal[4], self.canal[3])
            if not self.pstcanal:
                return

            skip_title, skip_word = should_skip_title(self.pstcanal)
            if skip_title:
                logger.info(
                    f"Skipping before queue: original='{self.canal[2]}' | final_search_title='{self.pstcanal}' | matched_exclusion='{skip_word}' | channel='{self.canal[0]}'")
                return

            if self.pstcanal in self.backdrop_cache:
                cached_path = self.backdrop_cache[self.pstcanal]
                if checkBackdropExistence(cached_path):
                    self.backrNm = cached_path
                    self.backdrop_refresh_count = 0
                    if not self.showBackdrop(cached_path):
                        try:
                            self.show_timer.start(
                                self.backdrop_refresh_delay, True)
                        except Exception:
                            pass
                    return

            backdrop_path = join(self.storage_path, f"{self.pstcanal}.jpg")
            self.backrNm = backdrop_path
            self.backdrop_refresh_count = 0

            if checkBackdropExistence(backdrop_path):
                if not self.showBackdrop(backdrop_path):
                    try:
                        self.show_timer.start(
                            self.backdrop_refresh_delay, True)
                    except Exception:
                        pass
            else:
                pdb.put(self.canal[:])
                self.runBackdropThread()
                try:
                    self.show_timer.start(self.backdrop_refresh_delay, True)
                except Exception:
                    pass

        except Exception as e:
            logger.error(f"Error in changed: {str(e)}")
            if self.instance:
                self.instance.hide()
            return

    def generateBackdropPath(self):
        """Generate filesystem path for current program's backdrop"""
        if len(self.canal) > 5 and self.canal[5]:
            self.pstcanal = get_search_title(
                self.canal[5], self.canal[4], self.canal[3])
            return join(self.storage_path, str(self.pstcanal) + ".jpg")
        return None

    def runBackdropThread(self):
        """Start background thread to wait for backdrop download"""
        Thread(target=self.waitBackdrop, daemon=True).start()

    def showBackdrop(self, backdrop_path=None):
        """Display the backdrop image"""
        if not self.instance:
            return False

        if not backdrop_path and self.backrNm:
            backdrop_path = self.backrNm

        if not backdrop_path or not checkBackdropExistence(backdrop_path):
            self.instance.hide()
            return False

        self.backrNm = backdrop_path

        try:
            pixmap = loadJPG(backdrop_path)
            if pixmap:
                self.instance.hide()
                self.instance.setPixmap(pixmap)
                self.instance.setScale(1)
                self.instance.show()
                return True
        except Exception as e:
            logger.warning("Backdrop load failed | file='{}' | error='{}'".format(
                backdrop_path, str(e)
            ))

        self.instance.hide()
        return False

    def refreshBackdrop(self):
        if not self.backrNm:
            return

        if self.showBackdrop(self.backrNm):
            self.backdrop_refresh_count = 0
            return

        self.backdrop_refresh_count += 1

        if self.backdrop_refresh_count < self.backdrop_refresh_max:
            try:
                self.show_timer.start(self.backdrop_refresh_delay, True)
            except Exception:
                pass
        else:
            logger.info(
                "Backdrop refresh stopped | file='{}'".format(self.backrNm))
            self.backdrop_refresh_count = 0

    def waitBackdrop(self):
        """Start/continue refresh loop for expected backdrop path"""
        if not self.instance or not self.canal[5]:
            return

        pstcanal = get_search_title(
            self.canal[5], self.canal[4], self.canal[3])
        backdrop_path = join(self.storage_path, "%s.jpg" % pstcanal)

        self.backrNm = backdrop_path
        self.backdrop_refresh_count = 0

        try:
            self.show_timer.start(self.backdrop_refresh_delay, True)
        except Exception:
            pass

    def check_valid_backdrop(self, path):
        """Verify Backdrop is valid JPEG and >1KB"""
        try:
            if not exists(path):
                return False

            if getsize(path) < 1024:
                remove(path)
                return False

            with open(path, 'rb') as f:
                header = f.read(2)
                if header != b'\xFF\xD8':  # JPEG magic number
                    remove(path)
                    return False
            return True
        except Exception as e:
            logger.error(f"Backdrop validation error: {str(e)}")
            return False

    def _log_info(self, message):
        self._write_log("INFO", message)

    def _log_debug(self, message):
        self._write_log("DEBUG", message)

    def _log_error(self, message):
        self._write_log("ERROR", message, error=True)

    def _write_log(self, level, message, error=False):
        """Centralized logging method writing to fixed log files"""
        try:
            if not hasattr(self, "log_dir"):
                log_dir = secure_log_dir

            if not exists(self.log_dir):
                makedirs(self.log_dir)

            if error:
                log_file = log_dir + "/BackdropX_errors.log"
            else:
                log_file = log_dir + "/BackdropX.log"

            with open(log_file, "a") as w:
                w.write("{} {}: {}\n".format(datetime.now(), level, message))
        except Exception as e:
            print("Logging error: {}".format(e))


class BackdropDB(MetrixHDbDownloadThread):
    """Handles Backdrop downloading and database management"""

    def __init__(self):
        super().__init__()
        self.backdrop_cache = {}
        self.provider_engines = [("tmdb", self.search_tmdb)]
        self.pstcanal = None
        self.logdbg = None
        self.extensions = extensions
        self.queued_backdrops = set()
        self.executor = ThreadPoolExecutor(max_workers=1)
        logger.info("BackdropDB executor configured | max_workers='1'")
        self.service_pattern = compile(
            r'^#SERVICE (\d+):([^:]+:[^:]+:[^:]+:[^:]+:[^:]+:[^:]+)')

        self.log_file = join(secure_log_dir, "BackdropDB.log")

    def run(self):
        """Main processing loop - handles incoming channel requests"""
        while True:
            canal = pdb.get()
            self.process_canal(canal)
            pdb.task_done()

    def process_canal(self, canal):
        """Schedule channel processing in thread pool"""
        self.executor.submit(self._process_canal_task, canal)

    def _process_canal_task(self, canal):
        """Download and process backdrop for a single channel"""
        try:
            self.pstcanal = get_search_title(canal[5], canal[4], canal[3])
            if not self.pstcanal:
                logger.error(f"Invalid channel name: {canal[0]}")
                return

            skip_title, skip_word = should_skip_title(self.pstcanal)
            if skip_title:
                logger.info(
                    f"Skipping title: original='{canal[2]}' | final_search_title='{self.pstcanal}' | matched_exclusion='{skip_word}' | channel='{canal[0]}'")
                return

            backdrop_path = join(BACKDROP_FOLDER, f"{self.pstcanal}.jpg")

            # Add to queue and process
            with Lock():
                self.queued_backdrops.add(self.pstcanal)

            try:
                # Check if a valid file already exists
                if self.check_valid_backdrop(backdrop_path):
                    return

                logger.info(
                    f"Starting download: original='{canal[2]}' | clean_for_tvdb='{clean_for_tvdb(canal[5])}' | final_search_title='{self.pstcanal}' | channel='{canal[0]}'"
                )

                for provider_name, provider_func in self.provider_engines:
                    try:
                        api_key = api_key_manager.get_tmdb_key()
                        if not api_key:
                            logger.warning(
                                f"Missing API key for {provider_name}")
                            continue

                        # Call the provider function to download the backdrop
                        result = provider_func(
                            dwn_backdrop=backdrop_path,
                            title=self.pstcanal,
                            shortdesc=canal[4],
                            fulldesc=canal[3],
                            channel=canal[0],
                            api_key=api_key
                        )
                        if result and self.check_valid_backdrop(backdrop_path):
                            logger.info(
                                f"Download successful with {provider_name}")
                            break

                    except Exception as e:
                        logger.error(f"Error with {provider_name}: {str(e)}")
                        continue

            finally:
                # Remove the channel from the queue after processing
                with Lock():
                    self.queued_backdrops.discard(self.pstcanal)

        except Exception as e:
            logger.error(f"Critical error in _process_canal_task: {str(e)}")
            logger.error(format_exc())

    def check_valid_backdrop(self, path):
        """Verify backdrop is valid JPEG and >1KB"""
        try:
            if not exists(path):
                return False

            if getsize(path) < 1024:
                remove(path)
                return False

            with open(path, 'rb') as f:
                header = f.read(2)
                if header != b'\xFF\xD8':  # JPEG magic number
                    remove(path)
                    return False
            return True
        except Exception as e:
            logger.error(f"backdrop validation error: {str(e)}")
            return False

    def mark_failed_attempt(self, canal_name):
        """Track failed download attempts"""
        self._log_debug(f"Failed attempt for {canal_name}")

    def _log_info(self, message):
        self._write_log("INFO", message)

    def _log_debug(self, message):
        self._write_log("DEBUG", message)

    def _log_error(self, message):
        self._write_log("ERROR", message, error=True)

    def _write_log(self, level, message, error=False):
        """Centralized logging method writing to fixed log files"""
        try:
            if not hasattr(self, "log_dir"):
                log_dir = secure_log_dir

            if not exists(self.log_dir):
                makedirs(self.log_dir)

            if error:
                log_file = log_dir + "/BackdropX_errors.log"
            else:
                log_file = log_dir + "/BackdropX.log"

            with open(log_file, "a") as w:
                w.write("{} {}: {}\n".format(datetime.now(), level, message))
        except Exception as e:
            print("Logging error: {}".format(e))


class BackdropAutoDB(MetrixHDbDownloadThread):
    """Automatic Backdrop download scheduler"""

    _instance = None

    def __init__(self, max_backdrops=1000):
        """Initialize the backdrop downloader with provider configurations"""
        super().__init__()
        self._stop_event = threading.Event()
        self._active_event = threading.Event()
        self._scan_lock = Lock()
        self.backdrop_download_count = 0
        self.max_backdrops = max_backdrops
        self.min_disk_space = 100
        self.max_backdrop_age = 30
        self.last_scan = 0

        self.abdb = OrderedDict()
        self.service_queue = []
        self.processed_titles = OrderedDict()

        # Set to TMDB only
        self.provider_engines = [("tmdb", self.search_tmdb)]

        self.pstcanal = None
        self.extensions = extensions
        self.backdrop_folder = "/tmp/backdrops"
        if not exists(self.backdrop_folder):
            makedirs(self.backdrop_folder, mode=0o700)

        # Set to default midnight scan
        self.scheduled_hour = 0
        self.scheduled_minute = 0

        self.last_scheduled_run = None
        self.log_file = join(secure_log_dir, "BackdropAutoDB.log")
        self.daemon = True
        self.force_immediate = False
        self.active = False
        self._active_event.set()

        # Exit instantly if config backdrop show is disabled
        if not hasattr(cfg, "show_backdrop") or not cfg.show_backdrop.value:
            return

        # Proceed with full initialization
        self.active = True
        self.backdrop_folder = self._init_backdrop_folder()
        logger.debug(
            "BackdropAutoDB: Automatic downloads ENABLED in configuration")

        if not exists("/tmp/agplog"):
            makedirs("/tmp/agplog")
        self._log_info("=== INITIALIZATION COMPLETE ===")
        self._log_info("=== READY ===")

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @property
    def active(self):
        return self._active_event.is_set()

    @active.setter
    def active(self, value):
        if value:
            self._active_event.set()
        else:
            self._active_event.clear()

    def start(self):
        if not self.is_alive():
            self.active = True
            super().start()

    def run(self):
        logger.info("BackdropAutoDB THREAD STARTED")
        try:
            while not self._stop_event.is_set():
                if self.force_immediate:
                    logger.debug("FORCED IMMEDIATE SCAN!")
                    self._execute_scheduled_scan()
                    self.force_immediate = False
                    continue

                now = datetime.now()
                next_run = self._calculate_next_run(now)
                logger.debug(f"Scheduled for: {next_run}")

                while datetime.now() < next_run and not self._stop_event.is_set():
                    remaining = (next_run - datetime.now()).total_seconds()

                    for _ in range(int(min(remaining, 1))):
                        if self._stop_event.is_set() or self.force_immediate:
                            break
                        sleep(1)

                    if self.force_immediate:
                        logger.debug("Interrupt waiting for manual scan")
                        break

                if not self._stop_event.is_set():
                    logger.debug("=== SCHEDULED SCAN START ===")
                    self._execute_scheduled_scan()

        except Exception as e:
            logger.error(f"ERROR: {str(e)}", exc_info=True)
        finally:
            logger.info("BackdropAutoDB STOPPED")

    def _execute_immediate_scan(self):
        with self._scan_lock:
            logger.debug("Starting immediate scan")
            self._full_scan()
            self._process_services()
            self.force_immediate = False
            self._stop_event.set()
            self._stop_event.clear()

    def _calculate_next_run(self, current_time):
        if self.force_immediate:
            return current_time - timedelta(seconds=1)

        next_run = datetime(
            year=current_time.year,
            month=current_time.month,
            day=current_time.day,
            hour=self.scheduled_hour,
            minute=self.scheduled_minute,
            second=0
        )
        if next_run <= current_time:
            next_run += timedelta(days=1)

        logger.debug(f"Next scan: {next_run.strftime('%Y-%m-%d %H:%M:%S')}")
        return next_run

    def _execute_scheduled_scan(self):
        """Run a single scheduled scan"""
        with self._scan_lock:
            if self.active:
                logger.debug("Starting scheduled scan")
                self._full_scan()
                self._process_services()
                self.last_scan = time()
                logger.debug("Scheduled scan completed")

    def stop(self):
        """Safe stop with timeout"""
        self.active = False
        self._active_event.set()
        if self.is_alive():
            self.join(timeout=2.0)
        logger.debug("BackdropAutoDB fully stopped")

    def _cleanup(self):
        self.active = False
        logger.info("BackdropAutoDB stopped gracefully")

    def _full_scan(self):
        """Scan all available TV services"""
        self._log_info("Starting full service scan")
        self.service_queue = self._load_services()
        self._log_info(
            f"Scan completed, found {len(self.service_queue)} services")

    def _load_services(self):
        """Load services from Enigma2 bouquet files"""
        services = OrderedDict()
        fav_path = "/etc/enigma2/userbouquet.favourites.tv"
        bouquets = [fav_path] if exists(fav_path) else []

        main_path = "/etc/enigma2/bouquets.tv"
        if exists(main_path):
            try:
                with open(main_path, "r") as f:
                    bouquets += [
                        "/etc/enigma2/" + line.split("\"")[1]
                        for line in f
                        if line.startswith("#SERVICE") and "FROM BOUQUET" in line
                    ]
            except Exception as e:
                self._log_error(f"Error reading bouquets.tv: {str(e)}")

        for bouquet in bouquets:
            if exists(bouquet):
                try:
                    with open(bouquet, "r", encoding="utf-8", errors="ignore") as f:
                        for line in f:
                            line = line.strip()
                            if line.startswith("#SERVICE") and "FROM BOUQUET" not in line:
                                service_ref = line[9:]
                                if self._is_valid_service(service_ref):
                                    services[service_ref] = None
                                    self.abdb[service_ref] = service_ref
                except Exception as e:
                    self._log_error(
                        f"Error reading bouquet {bouquet}: {str(e)}")

        return list(services.keys())

    def _is_valid_service(self, sref):
        """Validate service reference format"""
        parts = sref.split(':')
        if len(parts) < 6:
            return False
        return parts[3:6] != ["0", "0", "0"]

    def _process_services(self):
        """Process all services and download backdrops"""
        for service_ref in self.abdb.values():
            try:
                events = epgcache.lookupEvent(
                    ['IBDCTESX', (service_ref, 0, -1, 1440)])
                if not events:
                    self._log_debug(f"No EPG data for service: {service_ref}")
                    continue

                for evt in events:
                    canal = self._prepare_canal_data(service_ref, evt)
                    if canal:
                        self._download_backdrop(canal)

            except Exception as e:
                self._log_error(
                    f"Error processing service {service_ref}: {str(e)}")
                print_exc()

    def _prepare_canal_data(self, service_ref, event):
        try:
            # Get service name from service reference
            service_name = ServiceReference(service_ref).getServiceName()
            service_name = service_name.replace(
                "\xc2\x86", "").replace("\xc2\x87", "")

            # Safely get the raw event title (could be None)
            raw_title = event[4] or ""
            event_name = raw_title.strip()
            if not event_name:
                # nothing to search for, skip this event
                return None

            clean_title = get_search_title(event_name, event[6], event[5])

            logger.debug(f"Processing event: {event_name} -> {clean_title}")

            return [
                service_name,
                event[1],      # begin_time
                event_name,
                event[5],      # extended_desc
                event[6],      # short_desc
                clean_title,
            ]

        except Exception as e:
            logger.error(f"Failed to parse event: {str(e)}")
            return None

    def _download_backdrop(self, canal):
        """Download backdrop with provider fallback logic"""
        try:
            if not self._pre_download_checks(canal):
                return
            downloaded = False
            for provider_name, provider_func in self.provider_engines:
                if self._try_provider(provider_name, provider_func, canal):
                    downloaded = True
                    break
            if not downloaded:
                logger.error(f"Download failed for: {self.pstcanal}")
        except Exception as e:
            logger.error(f"Critical error: {str(e)}")
            print_exc()

    def _pre_download_checks(self, canal):
        """Run pre-download checks"""
        if not canal or len(canal) < 6:
            return False

        self.pstcanal = get_search_title(canal[5] or "", canal[4], canal[3])
        if not self.pstcanal:
            return False

        skip_title, skip_word = should_skip_title(self.pstcanal)
        if skip_title:
            logger.info(
                f"Skipping auto-download: original='{canal[2]}' | final_search_title='{self.pstcanal}' | matched_exclusion='{skip_word}' | channel='{canal[0]}'")
            return False

        if self.backdrop_download_count >= self.max_backdrops:
            return False

        if not self._check_storage():
            self._log_info("Download skipped due to insufficient storage")
            return False

        if not check_disk_space(BACKDROP_FOLDER, 10):
            logger.warning("Not enough space to download")
            return False

        return True

    def _try_provider(self, provider_name, provider_func, canal):
        """Try downloading with a specific provider"""
        try:
            api_key = api_key_manager.get_tmdb_key()
            if not api_key:
                logger.warning(f"Missing API key for {provider_name}")
                return False
            backdrop_path = join(BACKDROP_FOLDER, f"{self.pstcanal}.jpg")
            result = provider_func(
                dwn_backdrop=backdrop_path,
                title=self.pstcanal,
                shortdesc=canal[4],
                fulldesc=canal[3],
                channel=canal[0],
                api_key=api_key
            )
            if result:
                logger.debug(f"{provider_name} returned URL: {result}")
                if self._validate_download(backdrop_path):
                    return True
            else:
                logger.debug(f"{provider_name} returned no results")

        except Exception as e:
            logger.error(f"Error with {provider_name}: {str(e)}")

        return False

    def _validate_download(self, backdrop_path):
        """Verify the integrity of the downloaded file"""
        if checkBackdropExistence(backdrop_path) and getsize(backdrop_path) > 1024:
            self.backdrop_download_count += 1
            return True
        return False

    def _init_backdrop_folder(self):
        """Initialize the folder with validation"""
        try:
            return validate_media_path(
                BACKDROP_FOLDER,
                media_type="backdrops",
                min_space_mb=self.min_disk_space
            )
        except Exception as e:
            self._log_error(f"backdrops folder init failed: {str(e)}")
            fallback = "/tmp/backdrops"
            try:
                if not exists(fallback):
                    makedirs(fallback, mode=0o700)
            except BaseException:
                pass
            return fallback

    def _check_storage(self):
        """Version optimized using utilities"""
        try:
            if check_disk_space(self.backdrop_folder, self.min_disk_space):
                return True

            self._log_info("Low disk space detected, running cleanup...")
            delete_old_files_if_low_disk_space(
                self.backdrop_folder,
                min_free_space_mb=self.min_disk_space,
                max_age_days=self.max_backdrop_age
            )

            return check_disk_space(self.backdrop_folder, self.min_disk_space)

        except Exception as e:
            self._log_error(f"Storage check failed: {str(e)}")
            return False

    def _log_info(self, message):
        self._write_log("INFO", message)

    def _log_debug(self, message):
        self._write_log("DEBUG", message)

    def _log_error(self, message):
        self._write_log("ERROR", message, error=True)

    def _write_log(self, level, message, error=False):
        """Centralized logging method writing to fixed log files"""
        try:
            if not hasattr(self, "log_dir"):
                log_dir = secure_log_dir

            if not exists(self.log_dir):
                makedirs(self.log_dir)

            if error:
                log_file = log_dir + "/BackdropX_errors.log"
            else:
                log_file = log_dir + "/BackdropAutoDB.log"

            with open(log_file, "a") as w:
                w.write(f"{datetime.now()} {level}: {message}\n")
        except Exception as e:
            print(f"Logging error: {e}")


def checkBackdropExistence(backdrop_path):
    return exists(backdrop_path)


def is_valid_backdrop(backdrop_path):
    """Check if the backdrop file is valid (exists and has a valid size)"""
    return exists(backdrop_path) and getsize(backdrop_path) > 100


def clear_all_log():
    log_dir = secure_log_dir
    log_files = [
        log_dir + "/BackdropX_errors.log",
        log_dir + "/BackdropX.log",
        log_dir + "/BackdropAutoDB.log"
    ]
    for file in log_files:
        try:
            if exists(file):
                remove(file)
                logger.warning("Removed cache: {}".format(file))
        except Exception as e:
            logger.error("log_files cleanup failed: {}".format(e))


# Always load TMDB
logger.debug("Starting BackdropDB with TMDB provider")
with db_lock:
    if AgbDB is None or not AgbDB.is_alive():
        AgbDB = BackdropDB()
        AgbDB.daemon = True
        AgbDB.start()
        logger.debug("BackdropDB started with PID: %s" % AgbDB.ident)


# automatic download
if hasattr(cfg, "show_backdrop") and cfg.show_backdrop.value:
    logger.debug("Starting BackdropAutoDB...")

    # Stop existing instance if any
    if global_agb_auto_db:
        global_agb_auto_db.stop()
        global_agb_auto_db = None

    # Start new instance
    global_agb_auto_db = BackdropAutoDB()
    global_agb_auto_db.daemon = True
    global_agb_auto_db.start()
    logger.debug("BackdropAutoDB ACTIVE")
