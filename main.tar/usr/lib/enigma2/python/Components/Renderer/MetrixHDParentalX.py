#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

import sys
from os.path import join, exists, getsize
from re import findall
from json import load as json_load, dump as json_dump
from threading import Lock, Thread
import gettext

# Python 2/3 compatibility for urlopen
PY3 = sys.version_info[0] >= 3
if PY3:
    from urllib.request import urlopen
else:
    from urllib2 import urlopen

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, loadPNG, eEPGCache

from .MetrixHD_Utils import IMOVIE_FOLDER, logger
from .MetrixHD_lib import build_search_title, quoteEventName, clean_search_title, smart_capitalize_title, should_skip_title

# ==========================================
# PLUGIN CONFIGURATION FOR THIS RENDERER
# ==========================================
from Components.config import config, ConfigSubsection, ConfigOnOff, ConfigYesNo, ConfigText

if not hasattr(config.plugins, "MetrixHDSP"):
    config.plugins.MetrixHDSP = ConfigSubsection()

if not hasattr(config.plugins.MetrixHDSP, "info_parental_mode"):
    config.plugins.MetrixHDSP.info_parental_mode = ConfigOnOff(default=True)
if not hasattr(config.plugins.MetrixHDSP, "tmdb_api"):
    config.plugins.MetrixHDSP.tmdb_api = ConfigText(
        default="3c3efcf47c3577558812bb9d64019d65", visible_width=50, fixed_size=False)
if not hasattr(config.plugins.MetrixHDSP, "load_tmdb_api"):
    config.plugins.MetrixHDSP.load_tmdb_api = ConfigYesNo(default=False)

cfg = config.plugins.MetrixHDSP

class ApiKeyManager:
    def __init__(self):
        self.plugin_api_file = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixPoster/tmdb_api"

    def get_tmdb_key(self):
        if cfg.load_tmdb_api.value and exists(self.plugin_api_file):
            try:
                with open(self.plugin_api_file, "r") as f:
                    key = f.read().strip()
                    if key:
                        return key
            except Exception:
                pass
        return cfg.tmdb_api.value

api_key_manager = ApiKeyManager()
# ==========================================


if not IMOVIE_FOLDER.endswith("/"):
    IMOVIE_FOLDER += "/"

_ = gettext.gettext
cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')

PARENTAL_ICON_PATH = '/usr/share/enigma2/{}/parental/'.format(cur_skin)
if not exists(PARENTAL_ICON_PATH):
    PARENTAL_ICON_PATH = '/usr/share/enigma2/MetrixHD/parental/'

DEFAULT_RATING = 'UN'
NA_RATING = 'NA'
DEFAULT_ICON = 'FSK_UN.png'

RATING_MAP = {
    'TV-Y': '6', 'TV-Y7': '6', 'TV-G': '0', 'TV-PG': '16',
    'TV-14': '16', 'TV-MA': '18',
    'G': '0', 'PG': '12', 'PG-13': '16', 'R': '18',
    'NC-17': '18',
    'PEGI-12': '12', 'PEGI-16': '16', 'PEGI-18': '18',
    '': DEFAULT_RATING, 'NA': NA_RATING,
    'NOT RATED': NA_RATING, 'UNRATED': NA_RATING, 'UN': DEFAULT_RATING
}

try:
    lng = config.osd.language.value
    lng = lng[:-3]
except BaseException:
    lng = 'en'


class MetrixHDParentalX(Renderer):
    GUI_WIDGET = ePixmap

    def __init__(self):
        Renderer.__init__(self)
        self.last_event = None
        self.current_request = None
        self.current_request_key = None
        self.lock = Lock()
        self.epgcache = eEPGCache.getInstance()
        self.epgcache.load()

        self.adsl = True

        self.icon_path = join(PARENTAL_ICON_PATH, DEFAULT_ICON)
        self.storage_path = IMOVIE_FOLDER

    def get_search_title(self, title, shortdesc="", fulldesc=""):
        try:
            result = build_search_title(
                title or "", shortdesc or "", fulldesc or "")
            return smart_capitalize_title(result)
        except Exception:
            return smart_capitalize_title(clean_search_title(title or ""))

    def changed(self, what):
        try:
            is_enabled = config.plugins.MetrixHDSP.info_parental_mode.value
        except Exception:
            is_enabled = True

        if what is None or not self.adsl or not is_enabled or what[0] == self.CHANGED_CLEAR:
            self.last_event = None
            self.current_request_key = None
            if self.instance:
                self.instance.hide()
            return

        self.event = getattr(self.source, "event", None)
        if not self.event:
            self.last_event = None
            self.current_request_key = None
            if self.instance:
                self.instance.hide()
            return

        name = self.event.getEventName()
        if not name:
            self.last_event = None
            self.current_request_key = None
            if self.instance:
                self.instance.hide()
            return

        begin = self.event.getBeginTime()
        if begin is None:
            self.last_event = None
            self.current_request_key = None
            if self.instance:
                self.instance.hide()
            return

        current_event_hash = name + str(begin)
        if current_event_hash != self.last_event:
            self.last_event = current_event_hash
            self.start_data_fetch()

    def start_data_fetch(self):
        request_key = self.last_event
        if getattr(self, "current_request_key", None) == request_key:
            if self.current_request and self.current_request.is_alive():
                return
        self.current_request_key = request_key

        event_name = self.event.getEventName() or ""
        short_desc = self.event.getShortDescription() or ""
        ext_desc = self.event.getExtendedDescription() or ""
        year = self.extract_year(event_name, short_desc, ext_desc)

        self.current_request = Thread(target=self.fetch_data, args=(
            request_key, event_name, short_desc, ext_desc, year))
        self.current_request.start()

    def fetch_data(self, request_key, event_name, short_desc, ext_desc, year):
        try:
            is_enabled = config.plugins.MetrixHDSP.info_parental_mode.value
        except Exception:
            is_enabled = True
            
        if not is_enabled:
            return

        if self.current_request_key != request_key:
            return

        with self.lock:
            try:
                clean_title = self.get_search_title(
                    event_name.replace('\xc2\x86', '').replace('\xc2\x87', ''),
                    short_desc,
                    ext_desc
                )

                skip_title, skip_word = should_skip_title(clean_title)
                if skip_title:
                    logger.info("MetrixHDParentalX skipping title: original='{}' | final_search_title='{}' | matched_exclusion='{}'".format(
                        event_name, clean_title, skip_word
                    ))
                    if self.current_request_key == request_key and self.instance:
                        self.instance.hide()
                    return

                parent_json_file = join(
                    self.storage_path, "{} parental.json".format(clean_title))
                info_json_file = join(
                    self.storage_path, "{}.json".format(clean_title))

                data = None

                if exists(parent_json_file) and getsize(parent_json_file) > 0:
                    with open(parent_json_file, "r") as f:
                        data = json_load(f)
                    logger.info("MetrixHDParentalX loaded cached parental json | file='{}' | rated='{}'".format(
                        parent_json_file, str(data.get('Rated', ''))
                    ))
                    self.process_data(data, request_key,
                                      event_name, short_desc, ext_desc)
                    return

                if exists(info_json_file):
                    logger.info(
                        "MetrixHDParentalX info json present | file='{}'".format(info_json_file))

                if self.current_request_key != request_key:
                    return

                data = self.fetch_tmdb_parental(
                    clean_title, year, event_name, short_desc, ext_desc)

                if self.current_request_key != request_key:
                    return

                if data:
                    with open(parent_json_file, "w") as f:
                        json_dump(data, f, indent=2)
                    logger.info("MetrixHDParentalX saved parental json | file='{}' | rated='{}'".format(
                        parent_json_file, str(data.get('Rated', ''))
                    ))
                    self.process_data(data, request_key,
                                      event_name, short_desc, ext_desc)

            except Exception as e:
                logger.error("MetrixHDParentalX Data fetch error: {}".format(
                    str(e)), exc_info=True)

    def fetch_tmdb_parental(self, title, year, event_name, short_desc, ext_desc):
        try:
            api_key = api_key_manager.get_tmdb_key()
            if not api_key:
                return None

            search_kind = "multi"
            desc = "{}\n{}\n{}".format(
                event_name, short_desc, ext_desc).lower()
            if any(x in desc for x in ["season", "episode", "series", "serie", "s.", "ep.", "episod"]):
                search_kind = "tv"

            search_url = (
                "https://api.themoviedb.org/3/search/{}?api_key={}&language={}&query={}".format(
                    search_kind, api_key, lng, quoteEventName(title)
                ) + ("&year={}".format(year) if year and search_kind != "tv" else "")
            )
            with urlopen(search_url) as response:
                search_data = json_load(response)

            results = search_data.get("results", [])
            if not results:
                logger.warning("MetrixHDParentalX no TMDB results for parental")
                return None

            result = results[0]
            media_type = result.get("media_type", "")
            if not media_type:
                media_type = "tv" if search_kind == "tv" else "movie"
            if media_type not in ("movie", "tv"):
                media_type = "movie"

            content_id = result["id"]
            rated = ""

            if media_type == "movie":
                details_url = "https://api.themoviedb.org/3/movie/{}?api_key={}&language={}".format(
                    content_id, api_key, lng)
                cert_url = "https://api.themoviedb.org/3/movie/{}/release_dates?api_key={}".format(
                    content_id, api_key)
                with urlopen(details_url) as response:
                    details = json_load(response)
                with urlopen(cert_url) as response:
                    cert_data = json_load(response)
                for entry in cert_data.get("results", []):
                    if entry.get("iso_3166_1") == "US":
                        for rd in entry.get("release_dates", []):
                            cert = (rd.get("certification") or "").strip()
                            if cert:
                                rated = cert
                                break
                        if rated:
                            break
                details["Rated"] = rated
                details["media_type"] = "movie"
                return details

            else:
                details_url = "https://api.themoviedb.org/3/tv/{}?api_key={}&language={}".format(
                    content_id, api_key, lng)
                cert_url = "https://api.themoviedb.org/3/tv/{}/content_ratings?api_key={}".format(
                    content_id, api_key)
                with urlopen(details_url) as response:
                    details = json_load(response)
                with urlopen(cert_url) as response:
                    cert_data = json_load(response)
                for entry in cert_data.get("results", []):
                    if entry.get("iso_3166_1") == "US":
                        cert = (entry.get("rating") or "").strip()
                        if cert:
                            rated = cert
                            break
                details["Rated"] = rated
                details["media_type"] = "tv"
                return details

        except Exception as e:
            logger.error("MetrixHDParentalX TMDB API error: {}".format(str(e)))
            return None

    def process_data(self, data, request_key, event_name, short_desc, ext_desc):
        try:
            if self.current_request_key != request_key:
                return
            rated = (data.get("Rated", "") or "").strip().upper()
            logger.info("MetrixHDParentalX parental extracted | title='{}' | rated='{}'".format(
                self.get_search_title(event_name, short_desc, ext_desc), rated
            ))
            rating_code = RATING_MAP.get(rated, DEFAULT_RATING)
            icon_file = "FSK_" + rating_code + ".png"
            self.icon_path = join(PARENTAL_ICON_PATH, icon_file)

            if not exists(self.icon_path):
                self.icon_path = join(PARENTAL_ICON_PATH, DEFAULT_ICON)

            self.update_icon(self.icon_path, request_key)

        except Exception as e:
            self.icon_path = join(PARENTAL_ICON_PATH, DEFAULT_ICON)
            self.update_icon(self.icon_path, request_key)

    def update_icon(self, icon, request_key):
        if self.current_request_key != request_key:
            return
        if self.instance:
            self.instance.setPixmap(loadPNG(icon))
            self.instance.show()

    def extract_year(self, event_name, short_desc, ext_desc):
        try:
            desc = "{}\n{}\n{}".format(event_name, short_desc, ext_desc)
            years = findall(r'\b\d{4}\b', desc)
            if years:
                valid_years = [y for y in years if 1900 <= int(y) <= 2100]
                if valid_years:
                    return max(valid_years)
            return None
        except Exception:
            return None