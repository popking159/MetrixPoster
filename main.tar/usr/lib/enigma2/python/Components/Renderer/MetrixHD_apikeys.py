#!/usr/bin/python
# -*- coding: utf-8 -*-
###################################
# # __copyright__ = "AGP Team"  # #
# # __modified_by__ = "MNASR"   # #
###################################
# /usr/lib/enigma2/python/Components/Renderer/MetrixHD_apikeys.py
from __future__ import absolute_import, print_function
from Components.config import config, ConfigSubsection, ConfigOnOff, ConfigYesNo, ConfigText
from threading import Lock

api_lock = Lock()

# --- Initialize Shared Configuration Once ---
if not hasattr(config.plugins, "MetrixHDSP"):
    config.plugins.MetrixHDSP = ConfigSubsection()

    # Display toggles
    config.plugins.MetrixHDSP.show_poster = ConfigOnOff(default=True)
    config.plugins.MetrixHDSP.show_backdrop = ConfigOnOff(default=True)
    config.plugins.MetrixHDSP.show_logo = ConfigOnOff(default=True)

    # API provider toggles (Only TMDB)
    config.plugins.MetrixHDSP.tmdb = ConfigOnOff(default=True)
    config.plugins.MetrixHDSP.load_tmdb_api = ConfigYesNo(default=False)
    config.plugins.MetrixHDSP.tmdb_api = ConfigText(
        default="3c3efcf47c3577558812bb9d64019d65", visible_width=50, fixed_size=False)

# API keys dictionary mapping directly to the Enigma2 config
API_KEYS = {
    "tmdb_api": config.plugins.MetrixHDSP.tmdb_api.value,
}


def _refresh_api_keys():
    """Updates the dictionary dynamically if the user changes settings in the plugin"""
    with api_lock:
        API_KEYS["tmdb_api"] = config.plugins.MetrixHDSP.tmdb_api.value
    return True


_refresh_api_keys()
